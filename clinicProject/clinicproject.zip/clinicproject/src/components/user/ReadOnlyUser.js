import React from "react";

const ReadOnlyUser = ({appointment, handleEditClick, handleDeleteClick}) =>{
    return(
        <tr>
        <td>{appointment.date}</td>
        <td>{appointment.time}</td>
        <td>{appointment.doctor}</td>
        <td>
            <button type="button" onClick={(event)=>handleEditClick(event, appointment)}>Edit</button>
            <button type="button" onClick={(event)=>handleDeleteClick(event,appointment)}>Cancel</button>
        </td>
        </tr>
        
    )
}
export default ReadOnlyUser;