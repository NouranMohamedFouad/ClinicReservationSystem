import React, {Fragment, useState} from "react";
import  {nanoid} from 'nanoid';
import './Patient.css';
import data from "../../mock2-data.json";
import ReadOnlyUser from "./ReadOnlyUser";
import EditableUser from "./EditableUser";

function Patient() {
    const [appointments, setAppointments] = useState(data);
    
    const[addAppoData, setAddAppoData] = useState({
       
        date:'',
        time:'',
        doctor:''
    })

    const [editAppoData, setEditAppoData] = useState({
        date:'',
        time:'',
        doctor:''
    })

      const [editAppoID, setEditAppoID] = useState(null);

      const handleAddAppoChange =(event) =>{
        const fieldName= event.target.getAttribute('name');
        const fieldValue= event.target.value;
        
        const newAppoData ={...addAppoData};
        newAppoData[fieldName]=fieldValue;

        setAddAppoData(newAppoData);
    }

    const handleEditAppoChange =(event)=>{
        const fieldName = event.target.getAttribute("name");
        const fieldvalue = event.taret.value; 

        const newAppoData = {...editAppoData};
        newAppoData[fieldName]= fieldvalue;

        setEditAppoData(newAppoData);
    }

    const handleAddAppoSubmit =(event)=>{
         
        const newAppointment={
            id: nanoid(),
            appointment: addAppoData.appointment,
            doctor: addAppoData.doctor
        };

        const newAppointments =[...appointments, newAppointment ];
        setAppointments(newAppointments);
    };

      const handleEditAppoSubmit =(event)=>{
        const editedAppointment ={
            id: editAppoID,
            date: editAppoData.date,
            time: editAppoData.time,
            doctor: editAppoData.doctor
        }
        const newAppointments = [...appointments];
        const index = appointments.findIndex((appointment)=> 
        appointment.id === editAppoID)
        newAppointments[index]= editedAppointment;
        setAppointments(newAppointments);
        setEditAppoID(null);
      }

        const handleEditClick = (event,appointment)=> {
            setEditAppoID(appointment.id);

            const appoValues = {
               date: appointment.date,
               time: appointment.time,
               doctor: appointment.doctor
            }
              
            setEditAppoData (appoValues);
        };

        const handleDeleteClick =(appointmentID)=>{
          const newAppointments =[...appointments];
           const index = appointments.findIndex((appointment)=> appointment.id === appointmentID);
         
           newAppointments.splice(index, 1);
           setAppointments(newAppointments);
        }


    return (
        <div className="container">
          <div className="header">
            <div className="text">Hello User</div>
            <div className="underline"></div>
         </div>

          <div className="mwa3yd">
          <h2>My Appoinments</h2>
          <form onSubmit={handleEditAppoSubmit} >
          <table>
            <thead>
                <th colSpan={2}>Appointment</th>
                <th>Doctor</th>
                <th>Actions</th>
            </thead>
            <tbody>
                {appointments.map((appointment) => (
                    <Fragment>
                       {
                        editAppoID=== appointment.id ? (
                        <EditableUser
                         editAppoData={editAppoData}
                          handleAddAppoChange={handleEditAppoChange}
                         /> ):
                        (<ReadOnlyUser appointment={appointment}
                        handleEditClick={handleEditClick}
                        handleDeleteClick={handleDeleteClick}
                        />)
                       }
                
                    </Fragment>
                    
                ))}
            </tbody>
          </table>
          </form>

         
           <h2>Create New Appointment</h2>
           <form onSubmit={handleAddAppoSubmit}>
            <select name="doctorsnames" id="">
                <option value="j"> janna </option>
                <option> shahd </option>
                <option> nouran </option>
            </select>
            <select name="mwa3yddoctors" id="">
                <option> arr[i] </option>
                <option> 12/11 2pm </option>
                <option> 13/11 2pm </option>
            </select>
           <button type='submit'>choose</button>
           </form>
           </div>
        </div>
        
        )
}
export default Patient