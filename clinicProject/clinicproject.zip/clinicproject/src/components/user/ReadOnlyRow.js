import React from "react";
import './Patient.css'
const ReadOnlyRow =({slot, handleEditClick, handleDeleteClick}) =>{
    return(
     <tr>
        <td>{slot.Date}</td>
        <td>{slot.Time}</td>
        <td>
            <button type="button" onClick={(event)=> handleEditClick(event, slot)}>Edit</button>
            <button type="btton" onClick={()=> handleDeleteClick(slot.id)}>Cancel</button>
        </td>
      </tr>
    );
};

export default ReadOnlyRow;