import React from 'react'

const EditableUser =({editAppoData, handleEditAppoChange}) =>{
    return(
        <tr>
            <td>
                <input
                type="String" required="required"
                placeholder="enter date"  name="date"
                value={editAppoData.date}
                onChange={handleEditAppoChange}
                ></input>
            </td>
            <td>
            <input
                type="String" required="required"
                placeholder="enter time"  name="time"
                value={editAppoData.time}
                onChange={handleEditAppoChange}
                ></input>
            </td>
            <td>
            <input
                type="String" required="required"
                placeholder="enter doctor"  name="doctor"
                value={editAppoData.doctor}
                onChange={handleEditAppoChange}
                ></input>
            </td>
            <td>
                <button type="submit">save</button>
            </td>
        </tr>
    )
}
export default EditableUser;