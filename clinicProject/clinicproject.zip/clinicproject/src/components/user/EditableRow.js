import React from "react";
import "./EditableRow.css";

const EditableRow = ({editSlotData, handleEditSlotChange} ) =>{
    return(
      <tr>
        
        <td>
            <mybutton>
            <input type="string" required="required" 
             placeholder="enter date.."name="Date"
             value={editSlotData.date}
            onChange={handleEditSlotChange}></input> </mybutton>
        </td>

        <td>
        <mybutton>
        <input type="string" 
             required="required" 
             placeholder="enter time.."
             name="Time"
             value={editSlotData.time}
             onChange={handleEditSlotChange}></input></mybutton>
        </td>
        <td>
            <button type="submit">Save</button>
        </td>
     </tr>
    )
}
export default EditableRow