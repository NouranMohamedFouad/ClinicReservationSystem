import React, { useState, Fragment } from "react";
import {nanoid} from 'nanoid';
import './Doctor.css';
import data from "../../mock-data.json"
import ReadOnlyRow from "./ReadOnlyRow";
import EditableRow from "./EditableRow";

const Doctor=() =>{

  const[slots, setSlots]= useState(data);
  const[addSlotData,setAddSlotData] = useState({
    date : '',
    time :''
   });
   const[editSlotData, setEditSlotData]=useState({
    date : '',
    time :''
   })
const[editSlotId, setEditSlotID] = useState(null);

  const handleSlotChange = (event) => {
    //event.preventdefault();

    const fieldName = event.target.getAttribute("name");
    const fieldValue = event.target.value;
    
    const newSlotData ={...addSlotData};
    newSlotData[fieldName] = fieldValue;

    setAddSlotData(newSlotData);
   };
      const handleEditSlotChange = (event)=>{
        event.preventDefault();
         const fieldName= event.target.getAttribute("name");
         const fieldValue= event.target.value;

         const newSlotData ={...editSlotData};
         newSlotData[fieldName]= fieldValue;

         setEditSlotData(newSlotData);

      }

    const  handleSlotSubmit= (event) =>{
      //event.preventdefault();

      const newSlot= {
        id: nanoid(),
        date: addSlotData.date,
        time: addSlotData.time
      }

      const newSlots=[...slots,newSlot];
      setSlots(newSlots);

    };

      const handleEditSlotSubmit =(event)=>{
        const editedSlot ={
            id: editSlotId(),
            date: editSlotData.date,
            time: editSlotData.date
        }
        const newSlots =[...slots];
        const index = slots.findIndex((slot)=>
        slot.id===editSlotId)
        newSlots[index] = editedSlot;
        setSlots(newSlots);
        setEditSlotID(null);
      };

      

    const handleEditClick= (event, slot)=>{
      //event.preventdefault();
      setEditSlotID(slot.id);

      const slotValues={
        date: slot.date,
        time: slot.time
      }
      setEditSlotData(slotValues);
    }

    const handleDeleteClick = (slotID) =>{
        const newSlots=[...slots];
        const index= slots.findIndex((slot)=> slot.id===slotID);
         newSlots.splice(index, 1);
         setSlots(newSlots);
    }


    return (
        <div className="container">
          <div className="header">
            <div className="text">Hello Doctor</div>
            <div className="underline"></div>
         </div>
          
          <div className="slotat">
          <h2>My Slots</h2>
          </div>
          <form onSubmit={handleEditSlotSubmit}>
           <table>
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Time</th>
                  <th>Actions</th>
                </tr>
              </thead> 
              <tbody>
                {slots.map((slot)=> 
                (
                    <Fragment>
                        {editSlotId=== slot.id?( 
                        <EditableRow
                        editSlotData={editSlotData}
                        handleEditSlotChange={handleEditSlotChange}
                        handleEditClick={handleEditClick}
            
                        
                        />)
                  :(<ReadOnlyRow
                   slot={slot}
                    handleEditClick={handleEditClick}
                    handleDeleteClick={handleDeleteClick}
                    />)}
                    </Fragment>
                  
                ))} 
              </tbody>
           </table>
           </form>
           <div className="slotat">


           <h2>Create New Slot</h2>
           <form onSubmit={handleSlotSubmit}>

            <input 
            type="Date" 
            name="date" 
            placeholder="choose date"
            onChange={handleSlotChange}/>

            <input type="Time"
             name="time"
              placeholder="choose time"
              onChange={handleSlotChange}/>

           <button type='submit'>Add Slot</button>

           
           </form>
           </div>
        </div>
        
        )
}
export default Doctor