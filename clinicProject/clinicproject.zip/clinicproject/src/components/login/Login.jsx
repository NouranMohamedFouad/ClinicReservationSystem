import React, { useState } from "react";
import { Link } from "react-router-dom";
import './Login.css';

const Login = () => {

   
    return (
        <div className="container ">
         <div className="header">
            <div className="text">Log In</div>
            <div className="underline"></div>
         </div>
         <form>
         <div className="inputs">

            <div className="input">
                <label for="email" className="info">Email</label>
                <input type="email" placeholder="your email"/>
            </div>
            <div className="input">
                <label for="password" className="info">Password</label>
                <input type="password" placeholder="your password"/>
         </div>
         
         <div className="submit-container">
           
               <button type="submit" className="Login">Login</button>
              <button><Link to="/Signup" type="submit" className="Signup">Sign UP</Link></button> 
               
         </div>
        </div>
        </form>
        </div>
    )
}
export default Login