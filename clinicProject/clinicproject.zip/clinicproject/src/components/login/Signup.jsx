import React, { useState } from "react";
import { Link } from "react-router-dom";
import './Signup.css';

const Signup = () => {
    return (
        <div className="container ">
         <div className="header">
            <div className="text">Sign Up</div>
            <div className="underline"></div>
         </div>
         <form>
         <div className="inputs">

            <div className="input">
                <label for="email" className="info">Email</label>
                <input type="email" placeholder="your email"/>
            </div>
            <div className="input">
                <label for="password" className="info">Password</label>
                <input type="password" placeholder="your password"/>
            </div>
               
            <div className="input">
               <label for="usertype" className="info">User Type</label>
           
                <input type="radio" className="radio" value="patient"/>
                <label for="radio" className="usertype">Patient</label>
           
                <input type="radio" className="radio" value="Doctor"/>
                <label for="radio" className="usertype">Doctor</label>
                </div>
            </div>
            
            <div className="submit-container">
        
         <div className="submit-container">
           <button><Link to="/Login" type="submit" className="Signup">Sign UP</Link></button> 
          </div>
         </div>
         </form>
        </div>
    )
}
export default Signup
